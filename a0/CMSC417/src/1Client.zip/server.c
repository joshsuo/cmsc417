#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <argp.h>
#include <netinet/in.h>
//#include <sys/socket.h>
#include <unistd.h>
#include <time.h>
#include <poll.h>

#include "hash.h"


struct server_arguments {
	int port;
	char *salt;
	size_t salt_len;
};
 

error_t server_parser(int key, char *arg, struct argp_state *state) {
	struct server_arguments *args = state->input;
	error_t ret = 0;
	switch(key) {
	case 'p':
		/* Validate that port is correct and a number, etc!! */
		args->port = atoi(arg);
		if (0 /* port is invalid */) {
			argp_error(state, "Invalid option for a port, must be a number");
		}
		break;
	case 's':
		args->salt_len = strlen(arg);
		args->salt = malloc(args->salt_len+1);
		strcpy(args->salt, arg);
		break;
	default:
		ret = ARGP_ERR_UNKNOWN;
		break;
	}
	return ret;
}

void server_parseopt(struct server_arguments *args, int argc, char *argv[]) {

	/* bzero ensures that "default" parameters are all zeroed out */
	bzero(args, sizeof(*args));

	struct argp_option options[] = {
		{ "port", 'p', "port", 0, "The port to be used for the server" ,0},
		{ "salt", 's', "salt", 0, "The salt to be used for the server. Zero by default", 0},
		{0}
	};
	struct argp argp_settings = { options, server_parser, 0, 0, 0, 0, 0 };
	if (argp_parse(&argp_settings, argc, argv, 0, NULL, args) != 0) {
		printf("Got an error condition when parsing\n");
	}

    // if (!args->port) {
	// 	fputs("A port number must be specified\n", stderr);
	// 	exit(1);
	// }

	/* What happens if you don't pass in parameters? Check args values
	 * for sanity and required parameters being filled in */

	/* If they don't pass in all required settings, you should detect
	 * this and return a non-zero value from main */
	printf("Got port %d and salt %s with length %ld\n", args->port, args->salt, args->salt_len);
	//free(args.salt);

}


int main(int argc, char *argv[])
{
    // 1. Create a TCP socket
    // 2. Bind socket to a port
    // 3. Set socket to listen
    // 4. Repeatedly:
    //  a. Accept new connection
    //  b. Communicate
    //  c. Close the connection
    struct server_arguments args;

    //printf("I am the server.\n");

    server_parseopt(&args, argc, argv);

    // 1. Create a TCP socket
    int sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(sockfd < 0) {
        perror("Server Socket Failed");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in address;
    bzero(&address, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(args.port);

    // 2. Bind socket to a port
    //printf("%d\n",args.port);
    int sockbind = bind(sockfd, (struct sockaddr*)&address, sizeof(address));
    if(sockbind < 0) {
        perror("Bind Failed");
        exit(EXIT_FAILURE);
    }

    // 3. Set socket to listen
    if(listen(sockfd, SOMAXCONN) < 0) {
        perror("Listen Failed");
        exit(EXIT_FAILURE);
    }

    // 4. Repeatedly:
    //  a. Accept new connection
    //  b. Communicate
    //  c. Close the connection
    int new_sock;
    //socklen_t addrlen = sizeof(address);
    ssize_t num_bytes;
    //char buffer[1024] = {0};
    //char* hello = "Hello from server";

    while(1) {
        struct sockaddr_in client_addr;
        socklen_t addrlen = sizeof(client_addr);

        new_sock = accept(sockfd, (struct sockaddr*)&address, &addrlen);
        if(new_sock < 0) {
            perror("accept failed");
            exit(EXIT_FAILURE);
        }

        uint32_t init_recv_buff[2] = {0};

        num_bytes = recv(new_sock, init_recv_buff, 8, 0);  
        if(num_bytes < 0){
            perror("recv() failed");
		    exit(1);
        }

        printf("number received = %ld\n", num_bytes);
        int type = ntohl(init_recv_buff[0]);
        int num_hashRequest = ntohl(init_recv_buff[1]);

        printf("Type=%d\n", type);
        printf("N=%d\n", num_hashRequest);

        uint32_t ack_send_buff[2] = {0};
        ack_send_buff[0] = htonl(2);  // type=2 Acknowledgement
        ack_send_buff[1] = htonl((4 + 4 + 32) * num_hashRequest);   

        num_bytes = send(new_sock, ack_send_buff, 8, 0);
        if(num_bytes < 0){
            perror("send() failed");
		    exit(1);
        }

        size_t send_buf_len, recv_buf_len;
        recv_buf_len = UPDATE_PAYLOAD_SIZE;
        send_buf_len = 4 + 4 + 32;
        uint8_t *recv_buff = malloc(recv_buf_len);
        uint8_t *send_buff = malloc(send_buf_len);

        struct checksum_ctx *ctx = checksum_create((uint8_t *)args.salt, args.salt_len);

        //uint8_t buffer[UPDATE_PAYLOAD_SIZE];

        for (int i = 0; i < num_hashRequest; i++) {
            num_bytes = recv(new_sock, recv_buff, recv_buf_len, 0);  printf("num_bytes=%ld\n", num_bytes);
            if(num_bytes < 0){
                perror("HashRequest recv() failed");
                exit(1);
            }

            int type = ntohl(*(uint32_t *)recv_buff); // type=3
            printf("type=%d\n", type);
            int length = ntohl(*(uint32_t *)&recv_buff[4]);
            printf("length=%d\n", length);
            uint8_t *data = &recv_buff[8];

            bzero(send_buff, sizeof(*send_buff));
            //*(uint32_t *)send_buff = htonl(36 * locals->hashnum);
            *(uint32_t *)send_buff = htonl(4); 
            *(uint32_t *)&send_buff[4] = htonl(i); 

            //checksum_update(ctx, buffer);
            checksum_finish(ctx, data, length, send_buff + 8);

            send(new_sock, send_buff, send_buf_len, 0);


            checksum_reset(ctx);
        }
        checksum_destroy(ctx);

        close(new_sock);
    }

    close(sockfd);

    return 0;
}