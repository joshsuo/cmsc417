#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <argp.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>

struct client_arguments {
	char ip_address[16]; /* You can store this as a string, but I probably wouldn't */
	int port; /* is there already a structure you can store the address
	           * and port in instead of like this? */
	int hashnum;
	int smin;
	int smax;
	char *filename; /* you can store this as a string, but I probably wouldn't */
};

error_t client_parser(int key, char *arg, struct argp_state *state) {
	struct client_arguments *args = state->input;
	error_t ret = 0;
	int len;
	switch(key) {
	case 'a':
		/* validate that address parameter makes sense */
		strncpy(args->ip_address, arg, 16);
		if (0 /* ip address is goofytown */) {
			argp_error(state, "Invalid address");
		}
		break;
	case 'p':
		/* Validate that port is correct and a number, etc!! */
		args->port = atoi(arg);
		if (0 /* port is invalid */) {
			argp_error(state, "Invalid option for a port, must be a number");
		}
		break;
	case 'n':
		/* validate argument makes sense */
		args->hashnum = atoi(arg);
		break;
	case 300:
		/* validate arg */
		args->smin = atoi(arg);
		break;
	case 301:
		/* validate arg */
		args->smax = atoi(arg);
		break;
	case 'f':
		/* validate file */
		len = strlen(arg);
		args->filename = malloc(len + 1);
		strcpy(args->filename, arg);
		break;
	default:
		ret = ARGP_ERR_UNKNOWN;
		break;
	}
	return ret;
}

void client_parseopt(struct client_arguments *args, int argc, char *argv[]) {
    bzero(args, sizeof(*args));

	struct argp_option options[] = {
		{ "addr", 'a', "addr", 0, "The IP address the server is listening at", 0},
		{ "port", 'p', "port", 0, "The port that is being used at the server", 0},
		{ "hashreq", 'n', "hashreq", 0, "The number of hash requests to send to the server", 0},
		{ "smin", 300, "minsize", 0, "The minimum size for the data payload in each hash request", 0},
		{ "smax", 301, "maxsize", 0, "The maximum size for the data payload in each hash request", 0},
		{ "file", 'f', "file", 0, "The file that the client reads data from for all hash requests", 0},
		{0}
	};

	struct argp argp_settings = { options, client_parser, 0, 0, 0, 0, 0 };

	if (argp_parse(&argp_settings, argc, argv, 0, NULL, args) != 0) {
		printf("Got error in parse\n");
	}

	/* If they don't pass in all required settings, you should detect
	 * this and return a non-zero value from main */
	printf("Got %s on port %d with n=%d smin=%d smax=%d filename=%s\n",
	       args->ip_address, args->port, args->hashnum, args->smin, args->smax, args->filename);
	//free(args.filename);
}

int main(int argc, char *argv[])
{
    // 1. Create a TCP socket
    // 2. Establish a connection
    // 3. Communicate
    // 4. Close the connection
    struct client_arguments args;

    //printf("I am the client.\n");

    client_parseopt(&args, argc, argv);

    // 1. Create a TCP socket
    int sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if(sockfd < 0) {
        perror("client socket failed\n");
        exit(EXIT_FAILURE);
    }

    // 2. Establish a connection
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(args.port);

    // Convert IPv4 and IPv6 addresses from text to binary
    if (inet_pton(AF_INET, args.ip_address, &server_addr.sin_addr.s_addr) <= 0) {
        printf("Invalid address/ Address not supported \n");
        exit(EXIT_FAILURE);
    }

    int status = connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr));
    if(status < 0) {
        perror("Connection Failed\n");
        exit(EXIT_FAILURE);
    }

    // 3. Communicate
    uint8_t *send_buff = malloc(4 + 4 + args.smax);
    uint8_t *recv_buff = malloc(4 + 4 + 32);

    size_t send_buf_len, recv_buf_len;
    ssize_t num_bytes;

    *(uint32_t *)send_buff = htonl(1); 
    *(uint32_t *)&send_buff[4] = htonl(args.hashnum);    
                    for (int i = 0; i < 8; i++) printf("%02x", send_buff[i]);

    send_buf_len = 4 + 4; 
    num_bytes = send(sockfd, send_buff, send_buf_len, 0); //printf("Sent num_bytes = %ld\n", num_bytes);
    if(num_bytes < 0){
        perror("send() failed");
		exit(EXIT_FAILURE);
    }

    recv_buf_len = 4 + 4; 
    num_bytes = recv(sockfd, recv_buff, recv_buf_len, 0); //printf("Received num_bytes = %ld\n", num_bytes);
	if (num_bytes < 0) {
		perror("recv() failed");
		exit(1);
	} 
    
    printf("\nAcknowledgement Received: ");
    int type = ntohl(*(uint32_t *)recv_buff); 
    printf("Type=%d\n", type);
    int num_hashResponse = ntohl(*(uint32_t *)&recv_buff[4]);
    printf("Total length of all HashResponses=%d\n", num_hashResponse);

    srand(time(NULL));

    *(uint32_t *)send_buff = htonl(3);

    FILE* file = fopen(args.filename, "r");

    for (int i = 0; i < args.hashnum; i++) {
        int l = rand() % (args.smax - args.smin)  + args.smin;      
        *(uint32_t *)&send_buff[4] = htonl(l);  // length
        
        fgets((void *)&send_buff[8], l, file);     //read file
        send_buf_len = 4 + 4 + l;
        
        printf("Sending HashRequest with %d bytes\n", l);
        num_bytes = send(sockfd, send_buff , send_buf_len , 0);
        if (num_bytes < 0) {
            perror("HashRequest send() failed");
            exit(1);
        }

        recv_buf_len = 4 + 4 + 32;
        num_bytes = recv(sockfd, recv_buff , recv_buf_len , 0);
        if (num_bytes < 0) {
            perror("HashResponse recv() failed");
            exit(1);
        }
        if (num_bytes == 0) {
            fputs("Connection closed by host\n", stderr);
            exit(1);
        }

        int type = ntohl(*(uint32_t *)recv_buff);
        if(type == 4){
            printf("%u: 0x", ntohl(*(uint32_t *)&recv_buff[4]));
	    	for (int i = 0; i < 32; i++) printf("%02x", recv_buff[i+8]);
        }
		printf("\n");

    }

    fclose(file);
    free(send_buff);
    free(recv_buff);

    // 4. Close the connection
    close(sockfd);

    return 0;
}